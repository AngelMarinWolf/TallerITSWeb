<?php 

phpinfo();


?>